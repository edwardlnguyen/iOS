//
//  HypnosisView.h
//  playingwithviews
//
//  Created by edward nguyen on 8/4/15.
//  Copyright (c) 2015 edward nguyen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface HypnosisView : UIView

@end
