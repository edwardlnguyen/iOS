//
//  UserAgent.h
//  ConnectSdk
//
//  Created by Rockie Morgan on 10/17/14.
//  Copyright (c) 2014 Steve. All rights reserved.
//

#ifndef ConnectSdk_UserAgent_h
#define ConnectSdk_UserAgent_h

@interface UserAgent : NSObject

-(id) init;

-(NSString *) getUserAgent;

@end



#endif
